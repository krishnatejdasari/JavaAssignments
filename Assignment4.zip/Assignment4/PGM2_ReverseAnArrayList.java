package Assignment4;

import java.util.ArrayList;
import java.util.Collections;

public class PGM2_ReverseAnArrayList {

	public static void main(String[] args) {
		{						
	               						
	        ArrayList<String> arrlist = new ArrayList<String>(); 						
	 						
	       					
	        arrlist.add("Broadridge");         						
	        arrlist.add("SDET");        						
	        arrlist.add("Java");						
	        arrlist.add("Batch");						
	        arrlist.add("Four");         						
	        arrlist.add("Assignment");						
	                 						
	             						
	        System.out.println("Before Reverse ArrayList:");         						
	        System.out.println(arrlist);						
	         						
	               						
	        Collections.reverse(arrlist);						
	         						
	              						
	        System.out.println("After Reverse ArrayList:");         						
	        System.out.println(arrlist);						
	    }						
	}

}
