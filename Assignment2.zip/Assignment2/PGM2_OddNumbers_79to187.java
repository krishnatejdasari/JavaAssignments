package Assignment2;

public class PGM2_OddNumbers_79to187 {

	public static void main(String[] args) 		{					
	int n = 187;						
	System.out.print("Odd Numbers from 79 to "+n+" are: ");						
	for (int i = 79; i <= n; i++) {						
	   if (i % 2 != 0) {						
		System.out.print(i + " ");					
	   }						
	}						
   }							

}
